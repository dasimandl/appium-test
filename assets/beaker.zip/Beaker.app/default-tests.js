 [
  {
  "detail" : "Live Network Test Ads Using cMedia",
  "notes" : "Can return any ad available on the network",
  "name" : "CoCo - Live Test Ads",
  "serverType" : "coco",
  "cocoSettings" : {
  "endpoint" : "https://api.greystripe.com/s2s/api",
  "applicationId" : "74735"
  }
  },
  {
  "detail" : "Please Enter MID",
  "notes" : "Used to test a Specific MID",
  "name" : "CoCo - Specific MID test",
  "serverType" : "coco",
  "cocoSettings" : {
  "endpoint" : "https://adsx.greystripe.com/openx/www/delivery/ia.php",
  "applicationId" : "0aa12ab2-d455-11e2-8c5d-555075c8b431",
  "overrideMid" : true,
  "mid" : "1243771"
  }
  },
  {
  "detail" : "Please Enter AID, STID, & MID",
  "notes" : "Used to test a Specific MID on Core Platform",
  "name" : "Core Platform - Specific MID test",
  "serverType" : "corePlatform",
  "corePlatformSettings" : {
  "endpoint" : "https://s-usweb.dotomi.com/renderer/ubr/current/ubr_wrapper_mobile.html"
  }
  }
  ]

