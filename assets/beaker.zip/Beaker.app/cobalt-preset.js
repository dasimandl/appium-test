{
    "name": "New Test",
    "detail" : "Basic Test",
    "cobaltSettings" : {
        "endpoint" : "https://tools.greystripe.com/preview/renderAd.php"
    }
}

