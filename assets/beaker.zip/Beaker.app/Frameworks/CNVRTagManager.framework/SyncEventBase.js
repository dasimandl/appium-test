{
    "method": "syncEvent",
    "id": "---",
    "jsonrpc": "2.0",
    "params": {
        "appInfo": {
            "appInstallTime": "---",
            "sdkVersion":"---"
        },
        "eventGroup": "---",
        "deviceData": {
            "dnt": false,
            "os": "---",
            "id": "---",
            "connectionType": "---",
            "lang": "---",
            "hardware": "---",
            "ip": "---",
            "idfv": "---"
        },
        "appId": "---",
        "eventData": {
            "launchTime": "---"
        },
        "siteId": "---",
        "events": ["---"],
        "version": "---",
        "eventTime": "---"
    }
}
