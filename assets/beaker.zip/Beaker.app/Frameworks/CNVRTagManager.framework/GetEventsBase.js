{
    "method": "getEvents",
    "id": "---",
    "jsonrpc": "2.0",
    "params": {
        "appId": "---",
        "deviceData": {
            "id": "---"
        },
        "siteId": "---",
        "version": "---"
    }
}