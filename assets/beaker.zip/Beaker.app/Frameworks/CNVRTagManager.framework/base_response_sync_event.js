{
    "jsonrpc": "2.0",
    "id": "B7B7A481-4F1D-413E-93CE-8AC8EA8D192A",
    "result": {
        "actions": []
    }
}