{
    "jsonrpc": "2.0",
    "id": "9EFBA9C5-3043-41ED-A82D-D17F90CC190A",
    "result": {
        "qualifiedEvents": [{
                            "eventName": "Test",
                            "ignoreBatch": false
                            },
                            {
                            "eventName": "test",
                            "ignoreBatch": false
                            }],
        "batchInterval": 100,
        "expireEvents": 0
    }
}
