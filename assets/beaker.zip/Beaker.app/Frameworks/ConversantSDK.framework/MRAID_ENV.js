window.MRAID_ENV = {
    version: '3.0',
    sdk: 'Conversant Mobile SDK',
    sdkVersion: '%@',
    appId: '%@',
    ifa: '%@',
    limitAdTracking: %@,
    coppa: false
};

mraid = {
    state: "loading",
    getState: function() {
        return mraid.state;
    }
};
