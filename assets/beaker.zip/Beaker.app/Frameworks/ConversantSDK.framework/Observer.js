%@.addEventListener("%@",function(){
                          window.webkit.messageHandlers.%@.postMessage(%@);
                    });