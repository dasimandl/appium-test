{
    "name": "New Test",
    "detail" : "Basic Test",
    "cocoSettings": {
        "endpoint": "https://api.greystripe.com/s2s/api",
        "applicationId": "74735"
    }
}
