 [
  {
  "setName": "Cobalt MRAID Tests",
  "defaults":
  {
  "server": "http://adsx.greystripe.com/openx/www/delivery/ia.php",
  "guid": "296834ba-e559-11e4-b59c-d04f09e98198"
  },
  "optionals":
  {
  "useBudget": false,
  "useFrequencyCapping": false,
  "ipv4": "",
  "sendGPS": false
  },
  "tests": [
            { "name": "Integration Test-Standard integration test GUID",
            "queryParameters": [
                                { "guid": "51d7ee3c-95fd-48d5-b648-c915209a00a5" }
                                ],
            "notes": "Should load generic Conversant themed ad."
            },
            { "name": "getCurrentPosition",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1239188" }
                                ],
            "notes": "Should return current ad position x,y relative to getMaxSize dimensions"
            },
            { "name": "getDefaultPosition",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243767" }
                                ],
            "notes": "Should return default ad position x,y relative to getMaxSize dimensions"
            },
            { "name": "getMaxSize",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243768" }
                                ],
            "notes": "Should return available screen size in pixels minus tool/status bars"
            },
            { "name": "getPlacementType",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243771" }
                                ],
            "notes": "Return placement type: inline"
            },
            { "name": "getScreenSize",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243772" }
                                ],
            "notes": "Return total screen size in pixels"
            },
            { "name": "open",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243773" }
                                ],
            "notes": "Open url to IAD site"
            },
            { "name": "playVideo",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243774" }
                                ],
            "notes": "Play IAB video"
            },
            { "name": "resize - Allow Offscreen",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243775" }
                                ],
            "notes": "When set to true will allow the ad to resize offscreen, when false ad should resize centered"
            },
            { "name": "Resize - Custom Close Positions",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243778" }
                                ],
            "notes": "Should resize with custom close in indicated area"
            },
            { "name": "resize - Simple",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243779" }
                                ],
            "notes": "Resize ad as shown in icons with partial screen dimensions"
            },
            { "name": "setExpandProperties - All Params",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243780" }
                                ],
            "notes": "Should set the following properties: width:288,height:292,useCustomClose:true,isModal:true\nNote: isModal is read only\n"
            },
            { "name": "setExpandProperties - String Vs. Boolean",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243794" }
                                ],
            "notes": "Set the following properties: width:288,height:292,useCustomClose:'true'\nNote: In our SDK, should translate string 'true' to boolean true.\n"
            },
            { "name": "setExpandProperties - String Vs. Integer",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243795" }
                                ],
            "notes": "Should set the following properties: width:'288',height:'292',useCustomClose:true\nNote: In our SDK, should fail to change because values are not numbers\n"
            },
            { "name": "setExpandProperties - Width",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243796" }
                                ],
            "notes": "Should set expand width to 288px"
            },
            { "name": "setExpandProperties - Width Height",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243797" }
                                ],
            "notes": "Should set expand height / width to width:288\/height:292"
            },
            { "name": "setExpandProperties- Width Height UCC",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243798" }
                                ],
            "notes": "Should set values width:288,height:292,useCustomClose:true"
            },
            { "name": "setOrientationProperties - Allow Orientation Change",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243800" }
                                ],
            "notes": "Should set values: allowOrientationChange:false"
            },
            { "name": "setOrientationProperties - All Params",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243801" }
                                ],
            "notes": "Should set values: allowOrientationChange:false,forceOrientation:'portrait'"
            },
            { "name": "setOrientationProperties - Bad Params",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243802" }
                                ],
            "notes": "Param 'pineapple' should not be accepted"
            },
            { "name": "setOrientationProperties - Force Orientation",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243804" }
                                ],
            "notes": "Should set value: forceOrientation:'landscape'"
            },
            { "name": "setOrientationProperties - String Vs. Boolean",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243805" }
                                ],
            "notes": "Attempt set values: allowOrientationChange:'false',forceOrientation:'portrait'\nNote: should either fail to set or translate string value into boolean\n"
            },
            { "name": "setResizeProperties - All Params",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243806" }
                                ],
            "notes": "Should set values: width:295,height:290,offsetX:7,offsetY:8,customClosePosition:'top-left',allowOffscreen:false\n"
            },
            { "name": "setResizeProperties - Bad Allow Offscreen",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243807" }
                                ],
            "notes": "Attempt to set values: width:295,height:290,offsetX:7,offsetY:8,customClosePosition:'top-left',allowOffscreen:'pineapple'\nNote: should not accept bad param \"pineapple\"\n"
            },
            { "name": "setResizeProperties - Bad CCP Value",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243808" }
                                ],
            "notes": "Attempt to set values: width:295,height:290,offsetX:7,offsetY:8,customClosePosition:'pineapple',allowOffscreen:'false'\nNote: should not accept bad param \"pineapple\"\n"
            },
            { "name": "setResizeProperties - Omit Some Required",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243809" }
                                ],
            "notes": "Attempt to set values: width:295,offsetY:8\nNote incomplete values, should not set\n"
            },
            { "name": "setResizeProperties - Required Only",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243810" }
                                ],
            "notes": "Should set values: width:295,height:290,offsetX:7,offsetY:8,customClosePosition:'top-right',allowOffscreen:'true'"
            },
            { "name": "setResizeProperties - String Vs. Boolean",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243811" }
                                ],
            "notes": "Attempt to set values: width:295,height:290,offsetX:7,offsetY:8,customClosePosition:'top-left',allowOffscreen:'false'\nNote: Our SDK refuses the change to allowOffscreen because of the string 'false'\n"
            },
            { "name": "setResizeProperties - String Vs. Integer",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243812" }
                                ],
            "notes": "Attempt to set values: width:'295',height:'290',offsetX:'7',offsetY:'8',customClosePosition:'top-left',allowOffscreen:false\nShould fail to set or translate string values to int.\n"
            },
            { "name": "setResizeProperties - Too big \/ Too small",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243813" }
                                ],
            "notes": "Attempt to set values too big or too small for device screen size.\nShould fail to set values."
            },
            { "name": "Expand: Expand Again",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243814" }
                                ],
            "notes": "Both Expand Again Buttons Should do nothing."
            },
            { "name": "Expand: Get tests",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243815" }
                                ],
            "notes": "Should expand then buttons will get current expand properties."
            },
            { "name": "Expand: Orientation properties",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243816" }
                                ],
            "notes": "Should expand.  Buttons will return current orientation properties."
            },
            { "name": "Expand: Set before expand",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243817" }
                                ],
            "notes": "Should expand to full screen size."
            },
            { "name": "Expand: Simple",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243818" }
                                ],
            "notes": "should expand add to fullscreen"
            },
            { "name": "Expand: Two asset",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243819" }
                                ],
            "notes": "Expand ad to IAB URL"
            },
            { "name": "Expand: Two asset - Bad URL",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243820" }
                                ],
            "notes": "Should expand the current view due to bad url.\nShould have custom close area in upper right corner."
            },
            { "name": "Events: addEventListener - Multiple Events",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243821" }
                                ],
            "notes": "Event ads\/removes multiple events fires on error of bad setResizeProperties({ })"
            },
            { "name": "Events: addEventListener",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243822" }
                                ],
            "notes": "Event ads\/removes multiple events fires on error of bad setResizeProperties({ })"
            },
            { "name": "Bad Methods",
            "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243823" }
                            ],
            "notes": "These buttons should all result in nothing"
            },
            {
                "name": "Get Tests: getTests",
                "interstitial": "1",
                "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243824" }
                            ],
                "notes": "Get tests in interstitial ad."
            },
            {
                "name": "Supports: call/txt/cal/pic/vid",
                "queryParameters": [
                                { "override": "1" },
                                { "mid": "1243825" }
                            ],
                "notes": "Tests for call, text, calendar, picture, and inline video."
            
            }
            ]
  }, {
  "setName": "MPLX MRAID",
  "defaults": {
        "server": "http://adsx.greystripe.com/openx/www/delivery/ia.php",
        "targetServer": "http://adfarm.mediaplex.com/ad/fm/16179-216086-37843-0?mpt=0315008256&mpcr=&mpcrset=&mpvc=",
        "guid": "MEDIAPLEX-GUID"
  },
  "tests":  [
            { "name": "MPLX MRAID",
             "queryParameters": [
                                 { "chris": "isAwesome" }
                                 ],
             "notes": "Should load iframed content loaded with javascript."
             }
            ]
  },
  {
  "setName": "No Ad Test Cases",
  "defaults": {
  "server": "http://adsx.greystripe.com/openx/www/delivery/ia.php"
  },
  "tests": [ {
            "name": "Disabled Site Test",
            "queryParameters": [
                                { "guid": "2c15aaab-2551-4225-95ce-fb81fb456be8" }
                                ],
            "notes": "Simulates App/Site disabled in Publisher Admin\nResult: PSA"
            }, {
            "name": "New App Test",
            "queryParameters": [
                                { "guid": "6f887611-4b92-483a-94a3-48f71cb1d9c3" }
                                ],
            "notes": "Simulates App/Site when just approved\nResult: PSA"
            }, {
            "name": "Mobile No Ad Test",
            "queryParameters": [
                                { "guid": "c3dcb038-6fb9-48c4-af0c-b5dee97dd7c5" }
                                ],
            "notes": "Simulates App/Site No Ad Response\nResult: gsStatus=1, timeout=0"
            }, {
            "name": "Floating Default Test",
            "queryParameters": [
                                { "guid": "196b9dfa-390a-11e4-b653-2183e4091534" }
                                ],
            "notes": "Simulates A Floating Default\nResult: gsStatus=1, timeout=0"
            } ]
  }, {
  "setName": "Cobalt Simple Image Ads",
  "defaults": {
  "server": "http://adsx.greystripe.com/openx/www/delivery/ia.php",
  "guid": "51d7ee3c-95fd-48d5-b648-c915209a00a5"
  },
  "tests": [ {
            "name": "Simple Ad: 320x50",
            "notes": "Test for:  render, orientation change, impression pixel fire, click through, click trackers and close button.",
            "queryParameters": [ { "mid": "1074799" } ]
            }, {
            "name": "Simple Ad: 300x250",
            "notes": "Test for:  render, orientation change, impression pixel fire, click through, click trackers and close button.",
            "queryParameters": [ { "mid": "1074795" } ]
            }, {
            "name": "Simple Ad: 728x90",
            "notes": "Test for:  render, orientation change, impression pixel fire, click through, click trackers and close button.",
            "queryParameters": [ { "mid": "1074803" } ]
            }, {
            "name": "Simple Ad: Interstitial",
            "interstitial": "1",
            "notes": "Test for:  render, orientation change, impression pixel fire, click through, click trackers and close button.",
            "queryParameters": [ { "mid": "1074807" } ]
            } ]
  }, {
  "setName": "Bolt Image Ads",
  "defaults": {
  "server": "http://adsx.greystripe.com/openx/www/delivery/ia.php",
  "targetServer": "http://tools.greystripe.com/bolt/serveAd.php",
  "guid": "e4816cae-3f63-11e4-883e-f8c9fded7073"
  },
  "tests": [ {
            "name": "Basic BOLT Test",
            "notes": "Basic BOLT Ad request",
            "queryParameters": [ { "guid": "crobison" } ]
            }, {
            "name": "Image Ad: 320x50",
            "notes": "Test for:  render, orientation change, impression pixel fire, click through, click trackers and close button.",
            "queryParameters": [ { "mid": "1260084" } ]
            }, {
            "name": "Image Ad: 300x250",
            "notes": "Test for:  render, orientation change, impression pixel fire, click through, click trackers and close button.",
            "queryParameters": [ { "mid": "1260085" } ]
            }, {
            "name": "Image Ad: 728x90",
            "notes": "Test for:  render, orientation change, impression pixel fire, click through, click trackers and close button.",
            "queryParameters": [ { "mid": "1260086" } ]
            }, {
            "name": "Image Ad: Interstitial",
            "interstitial": "1",
            "notes": "Test for:  render, orientation change, impression pixel fire, click through, click trackers and close button.",
            "queryParameters": [ { "mid": "1260087" } ]
            } ]
  }
  ]
