{
    "name": "New Test",
    "detail" : "Basic Test",
    "customSettings" : {
        "endpoint" : "https://conversantmedia.com"
    }
}
