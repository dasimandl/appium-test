{
    "name": "New Test",
    "detail" : "Basic Test",
    "serverType" : "coco",
    "new" : true,
    "cocoSettings": {
        "endpoint": "https://api.greystripe.com/s2s/api",
        "applicationId": "74735"
    },
    "mplxSettings" : {
        "endpoint" : "https://adfarm.mediaplex.com/ad/js",
        "mediaId" : "16542-112413-3840-45"
    },
    "corePlatformSettings": {
        "endpoint" : "https://s-usweb.dotomi.com/renderer/ubr/current/ubr_wrapper_mobile.html"
    },
    "customSettings" : {
        "endpoint" : "https://conversantmedia.com"
    },
    "cobaltSettings" : {
        "endpoint" : "https://tools.greystripe.com/preview/renderAd.php"
    }
}
