{
    "name": "New Test",
    "detail" : "Basic Test",
    "corePlatformSettings": {
        "endpoint" : "https://s-usweb.dotomi.com/renderer/ubr/current/ubr_wrapper_mobile.html"
    }
}
