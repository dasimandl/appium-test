{
    "name": "New Test",
    "detail" : "Basic Test",
    "mplxSettings" : {
        "endpoint" : "https://adfarm.mediaplex.com/ad/js",
        "mediaId" : "16542-112413-3840-45"
    }
}
